

<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
           <?php echo $__env->make('layouts.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Violations</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">

                        <a href="<?php echo e(route('violations.show',$violation_id)); ?>" class="btn btn-default mb-1 mr-1">
                           back
                        </a>



                        
                    </ol>


                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <section class="content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Sanction List</h3>

                                <div class="card-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="table_search" class="form-control float-right"
                                            placeholder="Search">

                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <?php if(count($violations)>0): ?>
                                <div class="col-12 table-responsive" style="height: 70vh;">

                                    <table class="table table-sm table-hover table-head-fixed">
                                        <thead>
                                            <tr>

                                                <th >Ordinal number</th>
                                                <th >Details</th>
                                                <th >Deleted date</th>
                                                <th>Action</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>


                                                <td><?php echo e($sanction->offense); ?></td>
                                                <td><?php echo e($sanction->details); ?></td>
                                                <td><?php echo e($sanction->updated_at); ?></td>
                                                <td class='row'>
                                                    
                                                    <a href="<?php echo e(route('restoreDeletedViolationSanction', $sanction->id)); ?>" class="btn btn-sm ml-1 mb-1 btn-default">
                                                        <i class="fas fa-trash-restore"></i>
                                                    </a>
                                                    



                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>


                                <?php else: ?>
                                <p> Violation list empty</p>
                                <?php endif; ?>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </section>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<!-- Toastr -->
<script src="<?php echo e(asset('adminlte/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
    // CKEDITOR.replace('violationbody-ckeditor');
</script>

<script>
    $(function () {
        CKEDITOR.replaceClass = 'ckeditor';

        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
        $('#swaldanger').on("click", function () {

            Toast.fire({
                icon: 'question',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            });

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pupviolation\resources\views/pages/violationSanctionArchive.blade.php ENDPATH**/ ?>