<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/jquery-ui/jquery-ui.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <?php echo $__env->make('layouts.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Sanction Clear Offenders</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <section class="content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Offender List</h3>

                                
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                              <?php if(count($offenders)>0): ?>
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Filed By</th>
                                            <th>Student Number</th>
                                            <th>Name</th>
                                            <th>Course</th>
                                            <th>Total Offenses</th>
                                            <th>Actions</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php $__currentLoopData = $offenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td> <?php echo $offender->filedby; ?> </td>
                                        <td><?php echo $offender->studentNumber; ?></td>
                                        <td><?php echo $offender->name; ?></td>
                                        <td><?php echo $offender->course; ?></td>
                                        <td><?php echo e(count($offender->violationsCleared)); ?></td>
                                        <td>
                                            <a href="<?php echo e(asset('/SanctionCleared/'.$offender->id)); ?>"  class="btn btn-xs btn-default">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-default btn-xs" data-toggle="modal" data-target="#editOffender<?php echo e($offender->id); ?>">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </button>

                                                <!-- Modal -->
                                                <div class="modal fade" id="editOffender<?php echo e($offender->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Update <?php echo e($offender->studentNumber); ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                
                                                                <?php echo Form::open(['route' =>['offenders.update',$offender->id],'method'=>'POST']); ?>

                                                                
                                                                
                                                                     
                                                                    
                                                                    <div class="mb-3">
                                                                    
                                                                    <?php echo e(Form::label('studentNumber','Student Number')); ?>

                                                                    <?php echo e(Form::text('studentNumber', $offender->studentNumber, ['class' => 'form-control', 'placeholder' => '0000-0000-SP-0', 'aria-describedby' => 'student number'])); ?>

                                                                    <?php echo e(Form::hidden('filedby', Auth::user()->name .'/'. Auth::user()->role)); ?>

                                                                    </div>
                                                                    <div class="mb-3">
                                                                    <?php echo e(Form::label('studentName','Name')); ?>

                                                                    <?php echo e(Form::text('studentName', $offender->name, ['class' => 'form-control', 'aria-describedby' => 'course'])); ?>

                                                                    
                                                                    </div>
                                                                    
                                                                    <div class="mb-3">
                                                                    <?php echo e(Form::label('studentCourse','Course')); ?>

                                                                    
                                                                    <select class="form-control"  name="studentCourse" id="studentCourse" style="width: 100%;">
                                                                    <option value="<?php echo e($offender->course); ?>"><?php echo e($offender->course); ?></option>
                                                                    <option value="BSA">Bachelor of Science in Accountancy (BSA)</option>
                                                                    <option value="BSBA-HRM">Bachelor of Science in Business Administration major in Human Resource Management (BSBA-HRM)</option>
                                                                    <option value="BSBA-MM">Bachelor of Science in Business Administration major in Marketing Management (BSBA-MM)</option>
                                                                    <option value="BSENTREP">Bachelor of Science in Entrepreneurship (BSENTREP)</option>
                                                                    <option value="BSEDEN">Bachelor of Secondary Education major in English (BSEDEN)</option>
                                                                    <option value="BSEDMT">Bachelor of Secondary Education major in Mathematics (BSEDMT)</option>
                                                                    <option value="BSIT">Bachelor of Science in Information Technology (BSIT)</option>
                                                                    
                                                                    </select>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                    <?php echo e(Form::label('email','E-mail')); ?>

                                                                    <?php echo e(Form::email('studentEmail', $offender->email, ['class' => 'form-control', 'aria-describedby' => 'email'])); ?>

                                                                    
                                                                    </div>
                                                                    <div class="mb-3">
                                                                    <?php echo e(Form::label('contactNum','Contact Number')); ?>

                                                                    <?php echo e(Form::text('contactNum', $offender->contactnum, ['class' => 'form-control', 'aria-describedby' => 'contact number'])); ?>

                                                                    
                                                                    </div>
                                                                    
                                                            </div>
                                                            <div class="modal-footer">
                                                            <?php echo e(Form::hidden('_method','PUT')); ?>

                                                            <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                                            <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                                            
                                                            <?php echo Form::close(); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                        </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                              <?php else: ?>
                              <p> Offender list empty</p>
                              <?php endif; ?>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </section>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset('adminlte/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
  $( function() { 
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })


});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pupviolation\resources\views/pages/sanction_cleared.blade.php ENDPATH**/ ?>