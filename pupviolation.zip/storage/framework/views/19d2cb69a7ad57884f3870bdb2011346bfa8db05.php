
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/jquery-ui/jquery-ui.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <?php echo $__env->make('layouts.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Violations</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">





                        <!-- Button trigger modal -->

                        <button type="button" class="btn btn btn-success mb-1 mr-1" data-toggle="modal"
                            data-target="#newViolation">
                            new Violation
                        </button>
                        <a href="<?php echo e(route('offenders.index')); ?>" class="btn btn btn-primary mb-1 mr-1">
                            Back
                        </a>

                        <!-- Modal -->
                        <div class="modal fade" id="newViolation" tabindex="-1" aria-labelledby="newViolationTitle"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="newViolationTitle">Add Offenders</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            
                                            <?php echo Form::open(['route'
                                            =>['offenderview.store'],'method'=>'POST','class'=>'row p-2']); ?>

                                            <?php echo e(Form::hidden('offender_id', $offender->id)); ?>


                                            <div class="col-md-6">
                                                <?php echo e(Form::label('studentNumber','student Number')); ?>

                                                :
                                                <?php echo e(Form::label('studentNumber',$offender->studentNumber)); ?>

                                                <?php echo e(Form::hidden('studentNumber', $offender->studentNumber, ['class' => 'form-control', 'placeholder' => '0000-0000-SP-0', 'aria-describedby' => 'student number'])); ?>

                                                <?php echo e(Form::hidden('filedby', Auth::user()->name .'/'. Auth::user()->role)); ?>

                                            </div>
                                            <div class="col-md-6">
                                                <?php echo e(Form::label('',"Complete Name")); ?>

                                                :
                                                <?php echo e(Form::label('studentName',$offender->name)); ?>

                                                <?php echo e(Form::hidden('studentName', $offender->name, ['class' => 'form-control', 'aria-describedby' => 'course'])); ?>


                                            </div>

                                            <div class="col-md-6">
                                                <?php echo e(Form::label('studentCourse','Course :')); ?>

                                                <?php echo e(Form::label('studentCourse',$offender->course)); ?>


                                                <select class="form-control" name="studentCourse" id="studentCourse"
                                                    style="width: 100%;" hidden>
                                                    <option value="<?php echo e($offender->course); ?>" selected option>
                                                        <?php echo e($offender->course); ?></option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <?php echo e(Form::label('email','E-mail :')); ?>

                                                <?php echo e(Form::label('email',$offender->email)); ?>

                                                <?php echo e(Form::hidden('studentEmail', $offender->email,['class' => 'form-control', 'aria-describedby' => 'email'])); ?>


                                            </div>
                                            <div class="col-md-6 ml-md-auto">
                                                <?php echo e(Form::label('contactNum','Contact Number :')); ?>

                                                <?php echo e(Form::label('contactNum',$offender->contactnum)); ?>

                                                <?php echo e(Form::hidden('contactNum', $offender->contactnum, ['class' => 'form-control', 'aria-describedby' => 'contact number'])); ?>


                                            </div>

                                            <div class="col-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('violationid','Violation')); ?>

                                                    <select class="form-control select2bs4 select2" name="violationid"
                                                        id="violationid" style="width: 100%;">
                                                        <option>select Violation...</option>
                                                        <?php if(count($violations)>0): ?>
                                                        <?php $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($violation->id); ?>">
                                                            <?php echo e($violation->violationTitle); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php else: ?>
                                                        <option>violation list empty</option>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                        <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </ol>


                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <section class="content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo $offender->studentNumber." ".$offender->name; ?> Violation List
                                </h3>


                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <?php if(count($offender->violations)>0): ?>


                                <div class="col-12 table-responsive" style="height: 70vh;">

                                    <table class="table table-hover table-head-fixed table-striped">
                                        <thead>
                                            <tr>

                                                <th class="w-25">Violation Title</th>
                                                <th>number of offense</th>
                                                <th class="text-center">violation details</th>
                                                <th>status</th>
                                                <?php if(Auth::user()->role=="admin"||Auth::user()->role=="campusdirector"): ?>
                                                <th>Actions</th>
                                                <?php endif; ?>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $offender->violationsPending->groupBy('violationTitle'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $res = $violations->where('id','=',$violation[0]->id)->first();
                                            
                                            ?>
                                            <tr>

                                                <td>
                                                    
                                                    <?php echo e($violation[0]->violationTitle); ?>

                                                </td>
                                                <td>
                                                    <?php if(count($violation)==1): ?>
                                                    <p class="text-danger bg-white border border-warning rounded p-2 m-0 text-center"
                                                        style="color:#ffc107!important;">
                                                        <?php echo e(count($violation)); ?>st offense
                                                    </p>
                                                    <?php elseif(count($violation)==2): ?>
                                                    <p class="text-danger bg-white border rounded p-2 m-0 text-center"
                                                        style="color:#ff7504!important;border-color:#ff7504!important">
                                                        <?php echo e(count($violation)); ?>nd offense
                                                    </p>
                                                    <?php elseif(count($violation)==3): ?>
                                                    <p class="text-danger bg-white border rounded p-2 m-0 text-center"
                                                        style="color:#ff0404!important;border-color:#ff0404!important">
                                                        <?php echo e(count($violation)); ?>rd offense
                                                    </p>
                                                    <?php elseif(count($violation)>3&&count($violation)<21): ?> <p
                                                        class="bg-danger border rounded p-2 m-0 text-center"
                                                        style="color:#fff!important;border-color:#fffb04!important;">
                                                        <?php echo e(count($violation)); ?>th offense
                                                        </p>
                                                        <?php endif; ?>

                                                </td>
                                                <td>

                                                    <?php $__currentLoopData = $res->violationSanctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanctions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <?php if($sanctions->offense == count($violation)): ?>
                                                            <?php if($sanctions->offense==1): ?>
                                                            <p class="text-danger p-2 m-0 text-center text-bold"
                                                                style="color:#ffc107!important;">
                                                                <?php echo e($sanctions->offense); ?>st offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanctions->offense==2): ?>
                                                            <p class="text-danger p-2 m-0 text-center text-bold"
                                                                style="color:#ff7504!important;">
                                                                <?php echo e($sanctions->offense); ?>nd offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanctions->offense==3): ?>
                                                            <p class="text-danger p-2 m-0 text-center text-bold"
                                                                style="color:#ff0404!important;">
                                                                <?php echo e($sanctions->offense); ?>rd offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanctions->offense>3&&$sanctions->offense<21): ?> <p
                                                                class=" p-2 m-0 text-center text-bold"
                                                                style="color:#fff!important;">
                                                                <?php echo e($sanctions->offense); ?>th offense
                                                                </p>
                                                                <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                                <?php endif; ?>
                                                        
                                                        
                                                        
                                                        <?php elseif($sanctions->offense < count($violation)): ?>
                                                            <?php if($sanctions->offense==1): ?>
                                                            <p class="text-danger p-2 m-0 text-center text-bold"
                                                                style="color:#ffc107!important;">
                                                                <?php echo e($sanctions->offense); ?>st offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanctions->offense==2): ?>
                                                            <p class="text-danger p-2 m-0 text-center text-bold"
                                                                style="color:#ff7504!important;">
                                                                <?php echo e($sanctions->offense); ?>nd offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanctions->offense==3): ?>
                                                            <p class="text-danger  p-2 m-0 text-center text-bold"
                                                                style="color:#ff0404!important;">
                                                                <?php echo e($sanctions->offense); ?>rd offense
                                                            </p>
                                                            <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                            <?php elseif($sanction->offense>3&&$sanctions->offense<21): ?>
                                                            <p class="bg-danger p-2 m-0 text-center text-bold"
                                                                style="color:#fff!important;">
                                                                <?php echo e($sanctions->offense); ?>th offense
                                                                </p>
                                                                <p class="mb-2 text-bold text-center"><?php echo e($sanctions->details); ?></p>
                                                                <?php endif; ?>
                                                            
                                                        <?php endif; ?>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php
                                                        foreach ($violation as $item) {
                                                            if ($item->pivot->status>0) {
                                                                $pending = false;
                                                            }else {
                                                                $pending = true;
                                                            }
                                                        }
                                                        
                                                        ?>
                                                    
                                                    <?php if($pending == false): ?>
                                                    <p class="text-danger text-center bg-white border border-success rounded p-2 mb-1">
                                                        cleared 
                                                    </p>
                                                    
                                                    <?php else: ?>
                                                    <p class="text-danger text-center bg-white border border-danger rounded p-2 mb-1"
                                                        style="color:#ec6e06!important;">
                                                        pending
                                                    </p>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                <?php if(Auth::user()->role=="admin"||Auth::user()->role=="campusdirector"): ?>
                                                    <?php if($pending == false): ?>
                                                    <button type="button" class="btn btn-danger mx-1"
                                                        data-toggle="modal"
                                                        data-target="#revertnotice<?php echo e($violation[0]->id); ?>">
                                                        <i class="fas fa-times fa-fw"></i></button>
                                                    <div class="modal fade" id="revertnotice<?php echo e($violation[0]->id); ?>"
                                                        tabindex="-1" role="dialog"
                                                        aria-labelledby="revertmodalTitle<?php echo e($violation[0]->id); ?>"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg modal-dialog-centered"
                                                            role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header bg-danger">
                                                                    <h5 class="modal-title" id="revertmodalTitle">
                                                                        <?php echo e($violation[0]->violationTitle); ?>

                                                                    </h5>
                                                                    <button class="close" type="button"
                                                                        data-dismiss="modal" aria-label="close">
                                                                        <span aria-hidden="true"
                                                                            class="text-light">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body text-center">
                                                                    <p>
                                                                        Are you sure you want to revert this
                                                                        violation:
                                                                    </p>
                                                                    <p>
                                                                        <b> <?php echo e($violation[0]->violationTitle); ?></b>
                                                                    </p>
                                                                    <p>
                                                                        for:
                                                                        <b> <?php echo $offender->studentNumber."
                                                                            ".$offender->name; ?></b>
                                                                    </p>
                                                                    <p>
                                                                        to <span class="border rounded p-1"
                                                                            style="border-color:#ec6e06!important">pending</span>
                                                                        ?
                                                                    </p>
                                                                </div>
                                                                <div class="modal-footer" style="justify-content: center!important;">
                                                                    <?php echo Form::open(['route'=>['SanctionCleared.update',$offender->id],'method'
                                                                            => 'POST']); ?>

                                                                            <?php echo e(Form::hidden('action','revert')); ?>

                                                                            <?php echo e(Form::hidden('violation_id',$violation[0]->id)); ?>

                                                                            <?php echo e(Form::hidden('offender_id',$offender->id)); ?>

                                                                            <?php echo e(Form::button('yes', ['type' => 'submit','class'=>'btn btn-danger ml-auto'])); ?>

                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">no</button>
                                                                            <?php echo e(Form::hidden('_method','PUT')); ?>


                                                                    <?php echo Form::close(); ?>

                                                                    

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <button class="btn btn-success mx-1" type="button"
                                                        data-toggle="modal"
                                                        data-target="#clearnotice<?php echo e($violation[0]->id); ?>">
                                                        <i class="fa fa-check fa-fw"></i></button>
                                                    <div class="modal fade" id="clearnotice<?php echo e($violation[0]->id); ?>"
                                                        tabindex="-1" role="dialog" aria-labelledby="clearModalTitle"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header bg-success">
                                                                    <h5 class="modal-title" id="clearModalTitle">
                                                                        <?php echo e($violation[0]->violationTitle); ?></h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true"
                                                                            class="text-light">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body text-center">
                                                                    <p>
                                                                        Are you sure you want to clear this
                                                                        violation:
                                                                    </p>
                                                                    <p>
                                                                        <b> <?php echo e($violation[0]->violationTitle); ?></b>
                                                                    </p>
                                                                    <p>
                                                                        for:
                                                                        <b> <?php echo $offender->studentNumber."
                                                                            ".$offender->name; ?></b>
                                                                    </p>
                                                                </div>
                                                                
                                                                    <div class="modal-footer" style="justify-content: center!important;">
                                                                        
                                                                            <?php echo Form::open(['route'=>['SanctionCleared.update',$offender->id],'method'
                                                                            => 'POST']); ?>

                                                                            <?php echo e(Form::hidden('action','clear')); ?>

                                                                            <?php echo e(Form::hidden('violation_id',$violation[0]->id)); ?>

                                                                            <?php echo e(Form::hidden('offender_id',$offender->id)); ?>

                                                                            <?php echo e(Form::button('yes', ['type' => 'submit','class'=>'btn btn-success'])); ?>

                                                                            <button type="button" class="btn btn-default" data-dismiss="modal">no</button>
                                                                            <?php echo e(Form::hidden('_method','PUT')); ?>


                                                                            <?php echo Form::close(); ?>


                                                                            
                                                                        
                                                                    </div>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>


                                        
                                    </table>
                                </div>


                                <?php else: ?>
                                <p> Violation list empty</p>
                                <?php endif; ?>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </section>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<!-- Toastr -->
<script src="<?php echo e(asset('adminlte/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/select2/js/select2.full.min.js')); ?>"></script>


<script>
    $(function () {
        // CKEDITOR.replaceClass = 'ckeditor';
        //Initialize Select2 Elements
        $('.select2').select2()

        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
        $('#swaldanger').on("click", function () {

            Toast.fire({
                icon: 'question',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            });

        });



    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pupviolation\resources\views/pages/offenderview.blade.php ENDPATH**/ ?>