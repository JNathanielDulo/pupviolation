

<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <?php echo $__env->make('layouts.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Violation : <?php echo e($violation->violationTitle); ?></h1>
                </div><!-- /.col -->

                <?php if(Auth::user()->role=="admin"): ?>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">



                        <button type="button" class="btn btn-success mb-1 mr-1" data-toggle="modal"
                            data-target="#sanction_add">
                            New Sanction
                        </button>
                        <a href="/violationSanction/archive/<?php echo e($violation->id); ?>" class="btn btn-warning mb-1 mr-1 text-light">
                            Archive
                        </a>



                        <!-- Modal -->
                        <div class="modal fade" id="sanction_add" tabindex="-1" aria-labelledby="add new sanction"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="sanction_add">Add Sanction</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>

                                    <?php echo Form::open(['route' => ['violationSanction.store'],'method'=> 'POST']); ?>

                                    <div class="modal-body">
                                        <?php echo e(Form::hidden('violation_id', $violation->id, ['class' => 'form-control', 'placeholder' => 'nth number', 'aria-describedby' => 'Validation_id'])); ?>


                                        <div class="mb-3">
                                            <?php echo e(Form::label('OrdinalOffensenumber','Ordinal Offense number')); ?>

                                            <?php echo e(Form::number('OrdinalOffensenumber', '', ['class' => 'form-control', 'placeholder' => 'nth number', 'aria-describedby' => 'Ordinal Offense number'])); ?>



                                        </div>
                                        <div class="mb-3">
                                            <?php echo e(Form::label('details','Details',['class' => 'form-label'])); ?>

                                            <?php echo e(Form::text('details', '', ['class' => 'form-control', 'placeholder' => 'Details', 'aria-describedby' => 'Details'])); ?>



                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </ol>


                </div>
                <?php endif; ?>

                <!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <section class="content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Sanction List</h3>

                                <div class="card-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="table_search" class="form-control float-right"
                                            placeholder="Search">

                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <?php if(count($violation->violationSanctions)>0): ?>
                                <div class="col-12 table-responsive" style="height: 70vh;">

                                    <table class="table table-md table-hover table-head-fixed">
                                        <thead>
                                            <tr>

                                                
                                                <th>Ordinal number</th>
                                                <th class="w-50">Details</th>
                                                <th>last updated</th>
                                                <th class="w-auto">Actions</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $violation->violationSanctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                <td>
                                                    <?php if($sanction->offense==1): ?>
                                                    <span class="tag tag-success text-danger bg-white border border-warning rounded p-2" style="color:#ffc107!important;">
                                                        <?php echo e($sanction->offense); ?>st offense
                                                    </span>
                                                    <?php elseif($sanction->offense==2): ?>
                                                    <span class="tag tag-success text-danger bg-white border rounded p-2" style="color:#ff7504!important;border-color:#ff7504!important">
                                                        <?php echo e($sanction->offense); ?>nd offense
                                                    </span>
                                                    <?php elseif($sanction->offense==3): ?>
                                                    <span class="tag tag-success text-danger bg-white border rounded p-2" style="color:#ff0404!important;border-color:#ff0404!important">
                                                        <?php echo e($sanction->offense); ?>rd offense
                                                    </span>
                                                    <?php elseif($sanction->offense>3&&$sanction->offense<21): ?>
                                                    <span class="tag tag-success bg-danger  border rounded p-2" style="color:#fff!important;border-color:#fffb04!important;">
                                                        <?php echo e($sanction->offense); ?>th offense
                                                    </span>
                                                    <?php endif; ?></td>
                                                <td><?php echo e($sanction->details); ?></td>
                                                <td><?php echo e($sanction->updated_at); ?></td>
                                                <td class="row">

                                                    <button type="button" class="btn btn-sm ml-1 mb-1 btn-default"
                                                        data-toggle="modal"
                                                        data-target="#sanction_edit<?php echo e($sanction->id); ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="sanction_edit<?php echo e($sanction->id); ?>"
                                                        tabindex="-1" aria-labelledby="sanction_edit<?php echo e($sanction->id); ?>"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="validation_add">Edit
                                                                        Offense</h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <?php echo Form::open(['route' =>
                                                                ['violationSanction.update',$sanction->id],'method'=>
                                                                'POST']); ?>

                                                                <?php echo e(Form::hidden('violation_id', $violation->id, ['class' => 'form-control'])); ?>


                                                                <div class="modal-body">

                                                                    <div class="mb-3">
                                                                        <?php echo e(Form::label('editOrdinalOffensenumber','Ordinal Offense number')); ?>

                                                                        <?php echo e(Form::text('editOrdinalOffensenumber', $sanction->offense, ['class' => 'form-control', 'placeholder' => 'nth number', 'aria-describedby' => 'Ordinal Offense number'])); ?>



                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <?php echo e(Form::label('editdetails','Details',['class' => 'form-label'])); ?>

                                                                        <?php echo e(Form::text('editdetails', $sanction->details, ['class' => 'form-control', 'placeholder' => 'Details', 'aria-describedby' => 'Details'])); ?>



                                                                    </div>





                                                                </div>
                                                                <div class="modal-footer">

                                                                    <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                                                    <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                                                </div>
                                                                <?php echo e(Form::hidden('_method','PUT')); ?>

                                                                <?php echo Form::close(); ?>


                                                            </div>
                                                        </div>
                                                    </div>

                                                    <?php echo Form::open(['route'=>['violationSanction.destroy',$sanction->id],'method'
                                                    => 'POST']); ?>

        
                                                    <?php echo e(Form::button('<i class="fa fa-ban"></i>', ['type' => 'submit','class'=>'btn btn-sm btn-default ml-1 mb-1'])); ?>

                                                    <?php echo e(Form::hidden('_method','DELETE')); ?>


                                                    <?php echo Form::close(); ?>





                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>


                                <?php else: ?>
                                <p> Sanction list empty</p>
                                <?php endif; ?>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </section>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<!-- Toastr -->
<script src="<?php echo e(asset('adminlte/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
    CKEDITOR.replace('violationbody-ckeditor');

</script>

<script>
    $(function () {
        CKEDITOR.replaceClass = 'ckeditor';

        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
        $('#swaldanger').on("click", function () {

            Toast.fire({
                icon: 'question',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            });

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pupviolation\resources\views/pages/violationView.blade.php ENDPATH**/ ?>