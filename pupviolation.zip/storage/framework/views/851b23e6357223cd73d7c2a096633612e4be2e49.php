

<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
           <?php echo $__env->make('layouts.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Violations</h1>
                </div><!-- /.col -->

                <?php if(Auth::user()->role=="admin"): ?>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">



                        <button type="button" class="btn btn-success mb-1 mr-1" data-toggle="modal" data-target="#validation_add">
                            New Violation
                        </button>
                        <a href="violations/archive" class="btn btn-warning mb-1 mr-1 text-light">
                            Violation Archive
                        </a>



                        <!-- Modal -->
                        <div class="modal fade" id="validation_add" tabindex="-1" aria-labelledby="validation_add"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="validation_add">Add Violations</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>

                                    <?php echo Form::open(['route' => ['violations.store'],'method'=> 'POST']); ?>

                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <?php echo e(Form::label('violationTitle','Violation Title')); ?>

                                            <?php echo e(Form::text('violationTitle', '', ['class' => 'form-control', 'placeholder' => 'Title', 'aria-describedby' => 'Violation Title'])); ?>

                                            

                                        </div>
                                        <div class="mb-3">
                                            <?php echo e(Form::label('violationType','Type',['class' => 'form-label'])); ?>

                                            <select name="violationType" id="violationType" class="form-control">
                                                <option ><p class="text-muted">select violation Type...</p></option>
                                                <option value="major violation">Major violation</option>
                                                <option value="minor violation">Minor violation</option>
                                                
                                              </select>
                                            
                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </ol>


                </div>
                <?php endif; ?>
                
                <!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <section class="content">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Violation List</h3>

                                <div class="card-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="table_search" class="form-control float-right"
                                            placeholder="Search">

                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <?php if(count($violations)>0): ?>
                                <div class="col-12 table-responsive" style="height: 70vh;">

                                    <table class="table table-sm table-hover table-head-fixed">
                                        <thead>
                                            <tr>

                                                <th class="w-50">Violation Title</th>
                                                <th class="w-25">Type</th>
                                                <th class="w-auto">last updated</th>
                                                <?php if(Auth::user()->role=="admin"): ?>
                                                <th class="w-auto">Actions</th>
                                                <?php endif; ?>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>


                                                <td><?php echo e($violation->violationTitle); ?></td>
                                                <td>
                                                    <?php echo $violation->type; ?>

                                                </td>
                                                <td><?php echo e($violation->updated_at); ?></td>

                                                <?php if(Auth::user()->role=="admin"): ?>
                                                <td class='row'>
                                                    <a href="<?php echo e(asset('/violations/'.$violation->id)); ?>"  class="btn btn-sm ml-1 mb-1 btn-default">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm ml-1 mb-1 btn-default"
                                                        data-toggle="modal"
                                                        data-target="#validation_edit<?php echo e($violation->id); ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="validation_edit<?php echo e($violation->id); ?>"
                                                        tabindex="-1"
                                                        aria-labelledby="validation_edit<?php echo e($violation->id); ?>"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="validation_add">Edit
                                                                        Violations</h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <?php echo Form::open(['route' => ['violations.update',$violation->id],'method'=> 'POST']); ?>

                                                                    <div class="modal-body">

                                                                        <div class="mb-3">
                                                                            <?php echo e(Form::label('violationTitle','Violation Title')); ?>

                                                                            <?php echo e(Form::text('violationTitle', $violation->violationTitle, ['class' => 'form-control', 'placeholder' => 'Title', 'aria-describedby' => 'Violation Title'])); ?>

                                                                            

                                                                        </div>
                                                                        <?php echo e(Form::label('violationType','Type',['class' => 'form-label'])); ?>

                                                                        <select name="violationType" id="violationType" class="form-control">
                                                                            <option value="<?php echo e($violation->type); ?>" selected><?php echo e($violation->type); ?></p></option>
                                                                            <option value="major violation">Major violation</option>
                                                                            <option value="minor violation">Minor violation</option>
                                                                            
                                                                          </select>





                                                                    </div>
                                                                    <div class="modal-footer">

                                                                        <?php echo e(Form::button('Cancel',['class'=>'btn btn-default','data-dismiss'=>'modal'])); ?>

                                                                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                                                                    </div>
                                                                    <?php echo e(Form::hidden('_method','PUT')); ?>

                                                                    <?php echo Form::close(); ?>

                                                               
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <?php echo Form::open(['route'=>['violations.destroy',$violation->id],'method' => 'POST']); ?>

                                                    <?php echo e(Form::button('<i class="fa fa-ban"></i>', ['type' => 'submit','class'=>'btn btn-sm btn-default ml-1 mb-1'])); ?>

                                                    <?php echo e(Form::hidden('_method','DELETE')); ?>

                                                    
                                                    <?php echo Form::close(); ?>




                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>


                                <?php else: ?>
                                <p> Violation list empty</p>
                                <?php endif; ?>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </section>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<!-- Toastr -->
<script src="<?php echo e(asset('adminlte/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
    CKEDITOR.replace('violationbody-ckeditor');
</script>

<script>
    $(function () {
        CKEDITOR.replaceClass = 'ckeditor';

        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
        $('#swaldanger').on("click", function () {

            Toast.fire({
                icon: 'question',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            });

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pupviolation\resources\views/pages/violations.blade.php ENDPATH**/ ?>